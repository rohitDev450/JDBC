package com.jspider.springrest;

public class App {

}
